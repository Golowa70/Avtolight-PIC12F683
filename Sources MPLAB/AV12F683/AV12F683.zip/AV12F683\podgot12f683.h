#ifndef _PODGOT12F683_H
#define  _PODGOT12F683_H



extern void  fnPodgot (void);

#endif
