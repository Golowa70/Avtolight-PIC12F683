#ifndef INPUTPINS_H
#define INPUTPINS_H

extern void fnInputpins(void);


#endif